package com.snapsid.loginuicolors;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
